package ece325_lab_assignment4;

public class ZooShow {
	
	public static void main(String[] args) {
		// create the artist
		Artist karan = new Artist();

		// create the zoo
		Zoo edmontonValleyZoo = new Zoo();
		
		// while there are animals that still need feeding,
		// randomly select an animal from the zoo
		// feed it

		while(!edmontonValleyZoo.allAnimalsFed()){
			ZooAnimal animal = edmontonValleyZoo.getRandomAnimalToComeToStage();
			try {
				karan.feed(animal);
			}
			catch(NotPlayingException e) {
				System.err.println("Artist not playing!");
				karan.startPlaying();
			}
			catch(AlreadyFedException e){
				String name = animal.getName();
				System.err.println(name + " was already fed");
			}

		}
			// stop playing when all animals are fed
			karan.stopPlaying();
	}
}
