package ece325_lab_assignment4;

public class AlreadyFedException extends Exception {
    public AlreadyFedException(String message){
        super(message);
    }
}