package ece325_lab_assignment4;

public class NotPlayingException extends Exception {
    public NotPlayingException(String message){
        super(message);
    }
}