package ece325_lab_assignment4;

/**
 * The artist/band that is performing. You must finish this class.
 * @author corpaul
 *
 */
public class Artist implements ZooPerformer {
	/** 
	 * Indicates whether the artist is currently playing (= performing). 
	 */
	private boolean isPlaying;
	
	public Artist() {
		isPlaying = false;
	}
	
	/** 
	 * Feed the animal. Make sure to check whether we are allowed to feed this animal,
	 * and make sure to handle things correctly if we are not allowed to feed it. You are allowed
	 * to change this method's signature, if necessary.
	 * 
	 */
	public void feed(ZooAnimal animal) throws AlreadyFedException, NotPlayingException{
		// Throw exception if we are not playing
		if(!isPlaying){
			throw new NotPlayingException("Artist not playing yet");
		}

		//Throw exception if the animal has already been fed
		if(animal.isFedAlready()){
			throw new AlreadyFedException("This animal has already been fed");
		}
		
		//Feed the animal if no exceptions were thrown
		if (isPlaying && !animal.isFedAlready()){
			animal.feed();
		}	
	}

	/**
	 * Sometimes, artists get distracted, so there is a 50% chance that they start
	 * playing when you call this method. 
	 * 
	 */
	public void startPlaying() {
		//Generate a random number between 0 and 1
		double play = Math.random();
		//Depending on value of random number isPlaying is true or false 50% of the time
		if (play < 0.5) {
			isPlaying = true;
		} else {
			isPlaying = false;
		}
	}
	
	public void stopPlaying() {	
		isPlaying = false;
	}
	
}
